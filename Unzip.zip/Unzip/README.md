# Unzip

一款纯本地运行的多格式压缩 / 解压 Android 应用。Kotlin + Jetpack Compose (Material 3) 编写，支持 SAF 文件访问、前台任务、进度与取消，界面为中文（附英文）。

## 功能

### 解压 / 浏览

| 格式 | 浏览 | 解压 | 备注 |
|---|---|---|---|
| ZIP | ✅ | ✅ | ZIP64；传统 ZipCrypto 加密需密码 |
| 7Z | ✅ | ✅ | LZMA/LZMA2/BCJ/Delta/BZip2/Deflate；AES-256 加密需密码 |
| RAR | ✅ | ✅ | RAR4 / RAR5（junrar） |
| TAR | ✅ | ✅ | GNU / POSIX long name |
| TAR.GZ / TGZ | ✅ | ✅ | |
| TAR.BZ2 / TBZ2 | ✅ | ✅ | |
| TAR.XZ / TXZ | ✅ | ✅ | |
| TAR.ZST | ✅ | ✅ | 纯 Java 解码（Aircompressor） |
| GZIP / GZ | ✅ | ✅ | 单文件流 |
| BZIP2 / BZ2 | ✅ | ✅ | 单文件流 |
| XZ | ✅ | ✅ | 单文件流 |
| ZSTD / ZST | ✅ | ✅ | 单文件流 |
| LZ4 | ✅ | ✅ | 单文件流 |
| BROTLI / BR | ✅ | ✅ | 单文件流 |

### 压缩

ZIP、7Z（LZMA2）、TAR、TAR.GZ、TAR.BZ2、TAR.XZ、TAR.ZST、GZ、BZ2、XZ、ZST，压缩级别 0–9 可选。

### 体验

- 压缩包内文件夹导航、面包屑、搜索、多选解压
- 解压冲突策略：覆盖 / 跳过 / 自动重命名
- 后台前台服务 + 通知进度条，支持取消
- 记住最近打开的压缩包、默认解压目录
- 深浅色主题（跟随系统 / 手动）
- 全部处理在设备本地完成，不联网、不上传

## 界面结构

- **首页**：打开压缩包 / 创建压缩包入口、支持格式、最近记录
- **压缩包页**：格式与统计、搜索、目录浏览、解压全部 / 选中
- **压缩页**：选择文件或文件夹、格式、名称、级别、保存位置
- **设置**：主题、默认目录、冲突策略、支持格式、关于

## 技术栈

- Kotlin 2.3.21，AGP 8.13.2，Gradle 8.14.3，compileSdk/targetSdk 36，minSdk 26
- Jetpack Compose + Material 3（BOM 2025.06.01）
- Apache Commons Compress 1.28.0、XZ for Java 1.12、junrar 8.1.2、Aircompressor 2.0.3、Brotli dec 0.1.2
- DataStore Preferences（设置与最近记录）
- 单 Activity + 手写 Compose 导航；前台服务保活；SAF（DocumentFile）读写

## 目录结构

```
ZipForge/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradle/libs.versions.toml
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/dsha/zipforge/
        │   ├── MainActivity.kt / ZipForgeApp.kt
        │   ├── core/          # 格式定义、数据模型、路径清洗、格式化
        │   ├── io/            # ArchiveSource（File/SAF）、解压目标（本地/SAF）
        │   ├── archive/       # 读取器（Zip/7z/Tar/Rar/单流）与写入器
        │   ├── task/          # TaskManager + 前台服务 + 通知
        │   ├── data/          # DataStore 设置与最近记录
        │   └── ui/            # Compose 页面、主题、自绘图标
        └── res/               # 字符串（中/英）、主题、自适应图标
```

## 构建

本仓库在 ARM64 Android 容器内验证过构建。普通 x86_64 Linux / macOS 环境只需安装 JDK 17+ 与 Android SDK（platform 36、build-tools 35），直接：

```bash
./gradlew :app:assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

### ARM64 主机（如 Termux / 手机容器）注意事项

1. 官方 Android SDK 的 aapt2/zipalign 只有 x86_64 版本。需要一份 ARM64 的 aapt2，
   例如 Termux 的 `aapt2` 包（`packages.termux.dev`），并补齐其依赖库（libc++、libprotobuf、abseil、fmt、libexpat、libpng、libzopfli、zlib）。
2. AGP 只接受文件名为 `aapt2` 结尾的 ELF 可执行文件，并会传入 `--no-crash-recovery` 参数。
   本仓库使用一个很小的 C 包装程序（设置 `LD_LIBRARY_PATH`、过滤不支持的参数、exec 真正的 aapt2），
   通过 `gradle.properties` 的 `android.aapt2FromMavenOverride=/path/to/aapt2` 指定。
3. 若链接器提示找不到 `/linkerconfig/ld.config.txt`，创建一个空文件即可消除警告（AGP 会解析 aapt2 输出）。
4. 手机容器内存有限时，把 `org.gradle.jvmargs` 控制在 `-Xmx1280m` 左右、`org.gradle.workers.max=1`，
   并把 `kotlin.compiler.execution.strategy=in-process`，避免进程被系统回收。
5. 不要引入 `material-icons-extended`（数千个类会让 debug 构建的 dex 阶段内存爆掉）；
   本项目在 `ui/AppIcons.kt` 中自带所需矢量图标。

构建产物（debug 签名）位于 `app/build/outputs/apk/debug/app-debug.apk`，可直接安装。

## 已知限制

- 只读 RAR，不支持创建 RAR（RAR 为专有格式，无开源编码器）。
- 不创建加密 ZIP/7Z（读取加密包已支持）；后续可接入 zip4j 写入 AES。
- RAR 分卷、7Z 分卷暂不支持。
- 压缩包内文件预览（图片/文本）未实现，当前聚焦解压与打包。


## 更新记录

### 1.0.1
- 修复加密 ZIP 读取：`ZipFile` 构造函数参数顺序是 `(channel, password, encoding, useUnicodeExtraFields)`，
  之前把密码传到了字符集位置，任何带密码的 ZIP 都会抛 `UnsupportedCharsetException`。
- 修复 7Z 读取时缺少 `commons-lang3` 依赖导致的运行时崩溃（`NoClassDefFoundError: ArrayUtils`）。
- 修复 GZIP / BZIP2 / XZ 压缩时先 `finish()` 后 `close()` 造成的重复 trailer 或 NPE：
  现在统一只调用 `close()` 结束压缩流，TAR 系列由 `TarArchiveOutputStream.close()` 统一收尾。
- 补充 `commons-codec` 运行时依赖。
- 已验证：ZIP / ZIP-ZipCrypto / ZIP-AES / 7Z / 7Z-AES / TAR.GZ / TAR.BZ2 / TAR.XZ / GZIP / BZIP2 / ZSTD / RAR4 / RAR5 的读取链路。

## 回归测试

`tools/enginetest/` 内置一套纯 JVM 测试，直接调用生产代码使用的同一套压缩库 API：

```bash
cd tools/enginetest && ./run.sh
```

覆盖 7Z/ZIP/TAR.GZ 写入回读、GZIP/ZSTD 往返、RAR4/RAR5 读取、加密 7Z、ZipCrypto/AES ZIP、
压缩流收尾方式与 Zip Slip 路径清洗，共 20 项断言。
